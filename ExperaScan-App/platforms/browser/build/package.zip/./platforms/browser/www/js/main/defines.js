// Define global vars
var STORAGE_PRODUCTS = "products";